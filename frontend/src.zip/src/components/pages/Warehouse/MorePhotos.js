import React from 'react';

const MorePhotos = () =>
{
    return (
        <>
            <h1>more photos under construction...</h1>
        </>
    );
}

export default MorePhotos;
