import React from 'react';
import { Link } from 'react-router-dom';

import './test.css';

const BookShow = () =>
{
    return (
        <div className='seat-list-container'>
            <h1>These are all the available seats</h1>
            <div className='seat-list'>
                <Link to="" id='01' className='link'>01</Link>
                <Link to="" id='02' className='link'>02</Link>
                <Link to="" id='03' className='link'>03</Link>
                <Link to="" id='04' className='link'>04</Link>
                <Link to="" id='05' className='link'>05</Link>
                <Link to="" id='06' className='link'>06</Link>
                <Link to="" id='07' className='link'>07</Link>
                <Link to="" id='08' className='link'>08</Link>
                <Link to="" id='09' className='link'>09</Link>
                <Link to="" id='10' className='link'>10</Link>
                <br />
                <br />
                <br />
                <Link to="" id='11' className='link'>11</Link>
                <Link to="" id='12' className='link'>12</Link>
                <Link to="" id='13' className='link'>13</Link>
                <Link to="" id='14' className='link'>14</Link>
                <Link to="" id='15' className='link'>15</Link>
                <Link to="" id='16' className='link'>16</Link>
                <Link to="" id='17' className='link'>17</Link>
                <Link to="" id='18' className='link'>18</Link>
                <Link to="" id='19' className='link'>19</Link>
                <Link to="" id='20' className='link'>20</Link>
                <br />
                <br />
                <br />
                <Link to="" id='21' className='link'>21</Link>
                <Link to="" id='22' className='link'>22</Link>
                <Link to="" id='23' className='link'>23</Link>
                <Link to="" id='24' className='link'>24</Link>
                <Link to="" id='25' className='link'>25</Link>
                <Link to="" id='26' className='link'>26</Link>
                <Link to="" id='27' className='link'>27</Link>
                <Link to="" id='28' className='link'>28</Link>
                <Link to="" id='29' className='link'>29</Link>
                <Link to="" id='30' className='link'>30</Link>
            </div>
        </div>
    );
}

export default BookShow;
